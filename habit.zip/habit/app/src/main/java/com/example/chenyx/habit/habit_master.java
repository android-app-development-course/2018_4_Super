package com.example.chenyx.habit;

import android.app.Dialog;

/**
 * Created by chenyx on 18-11-16.
 */

public class habit_master {
    private String habit_name;
    private String remind_que;
    private int replay_time;    //每天就是1time 1day
    private int replay_day;
    private boolean remindORnot;    //ture为需要提醒
    private Dialog timeDialog;  //提醒时间（remindORnot为false则无）
    //还有一个记录已打卡日期的List，具体看你怎么记录，你自己添加


    public String getHabit_name() {
        return habit_name;
    }

    public void setHabit_name(String habit_name) {
        this.habit_name = habit_name;
    }

    public String getRemind_que() {
        return remind_que;
    }

    public void setRemind_que(String remind_que) {
        this.remind_que = remind_que;
    }

    public int getReplay_time() {
        return replay_time;
    }

    public void setReplay_time(int replay_time) {
        this.replay_time = replay_time;
    }

    public int getReplay_day() {
        return replay_day;
    }

    public void setReplay_day(int replay_day) {
        this.replay_day = replay_day;
    }

    public boolean isRemindORnot() {
        return remindORnot;
    }

    public void setRemindORnot(boolean remindORnot) {
        this.remindORnot = remindORnot;
    }

    public Dialog getTimeDialog() {
        return timeDialog;
    }

    public void setTimeDialog(Dialog timeDialog) {
        this.timeDialog = timeDialog;
    }
}
